package com.example.persona.services;

import com.example.persona.entities.Autor;

public interface AutorService extends BaseService<Autor, Long> {
}
